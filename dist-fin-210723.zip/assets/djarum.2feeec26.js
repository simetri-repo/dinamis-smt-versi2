var a="/assets/ngurahrai.8f0f8202.jpg",s="/assets/rsudtarakan.4612dad2.jpg",r="/assets/bankindo.cdcff414.jpg",t="/assets/djarum.f666d37c.jpg";export{a as _,s as a,r as b,t as c};
